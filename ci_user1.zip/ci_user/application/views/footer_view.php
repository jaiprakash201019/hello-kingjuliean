	<div id="footer">
    	&copy; 2011 <a href="http://www.webinone.net/">WebInOne</a> All Rights Reserved.
    </div><!--	<div class="footer">-->
</div><!--<div id="wrapper">-->
</body>
</html>